Arduino Cloud historic data

variables:
  - id: 666206c0-932c-47d3-a5e3-bab92807bf33
    name: accel_x
    thingName: SIH_demo
  - id: fef5b004-a374-42c7-9359-4ec465a62215
    name: accel_y
    thingName: SIH_demo
  - id: 01ca064c-0fc3-413a-9adf-464d78bece32
    name: vibrations
    thingName: SIH_demo
  - id: 0f723667-6d35-442d-ab79-2b2e5ec6f0a1
    name: accel_z
    thingName: SIH_demo
from: 2024-09-06T18:40:13Z
to: 2024-09-07T23:59:59Z

Have fun! :)
